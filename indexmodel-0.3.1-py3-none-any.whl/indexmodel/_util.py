import faiss
import numpy as np
import pandas as pd

from typing import Union
from pathlib import Path
from indexmodel import SSIndex

INDEX_SAVE_NAME = "index.npy"
META_DATA_SAVE_NAME = "meta.parquet"


def save_index(index: SSIndex, path: Union[Path, str]) -> None:
    index_data = faiss.serialize_index(index.index)
    np.save(Path(path) / INDEX_SAVE_NAME, index_data)
    index.meta.to_parquet(Path(path) / META_DATA_SAVE_NAME)


def load_index(path: Union[Path, str], mapping: str) -> SSIndex:
    index = faiss.deserialize_index(np.load(Path(path) / INDEX_SAVE_NAME))
    meta = pd.read_parquet(Path(path) / META_DATA_SAVE_NAME)
    return SSIndex(index, meta, mapping)
