import numpy as np
from typing import Callable
from itertools import groupby

# implementation via numpy better/faster?

def quantifier(search_results: np.array, func: Callable, max_dis= None) -> np.array:
    results = []
    for search in search_results:
        if max_dis:
            search = list(filter(lambda x: x if (x[1] <= max_dis) else None, search))
            if not search:
                results.append([('-1', 0.0)])
                continue
        results.append(func(search))
    return results

# return the min dis object ( naive qualifier )
def min_dis(search: np.array):
    return min(search, key=lambda x: x[1])

# most  occurens ( naive qualifier )
def occurs_most_often(search: np.array):
    lens =  []
    for key, group in groupby(sorted(search), key=lambda x: x[0]):
        lens.append((key, len(list(group))))
    return max(lens, key= lambda x: x[1])
from math import exp

# confidence score from "Fine-grained Categorization and dataset bootstrapping
# using Deep Metric Learning with Humans in the Loop"
def confidence(gamma, top=2):
    def inner(search: np.array):
        data = []
        def weight(dis, gamma):
            return exp(-gamma * dis)
        
        for key, group in groupby(sorted(search), key=lambda x: x[0]):
            data.append((key, sum([weight(x, gamma) for _, x in group])))
        
        try:
            return sorted([(x[0], x[1] / sum([y[1] for y in data])) 
                       for x in data], key= lambda x: x[1], reverse=True)[:top]
        except ZeroDivisionError:
            return [('-1', 0.0, search)] 
    return inner
    